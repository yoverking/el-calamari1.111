/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ClerkProvider } from '@clerk/clerk-react';
import Home from './pages/Home';
import Login from './pages/Login';

// Import your publishable key
const PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;

if (!PUBLISHABLE_KEY) {
  console.warn("Missing Publishable Key (VITE_CLERK_PUBLISHABLE_KEY)");
}

export default function App() {
  return (
    <ClerkProvider publishableKey={PUBLISHABLE_KEY || "pk_test_bWlzc2luZy1rZXk="} afterSignOutUrl="/">
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </Router>
    </ClerkProvider>
  );
}
